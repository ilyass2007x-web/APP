package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.dataOrThrow

/**
 * Articles repository.
 *
 * Wraps the article list + article detail + article-like endpoints.
 */
class ArticlesRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of published articles. */
    suspend fun getArticles(cursor: String? = null, limit: Int = 10): ArticleListResponse {
        return api.getArticles(limit = limit, cursor = cursor).dataOrThrow()
    }

    /** Fetch a single article by ID (includes the full content body). */
    suspend fun getArticle(id: String): ArticleDetailDto {
        return api.getArticle(id).dataOrThrow()
    }

    /** Toggle like on an article. */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return api.toggleArticleLike(id = id, origin = origin).dataOrThrow()
    }

    /** Convenience: fetch the first page of articles as a flat list. */
    suspend fun getFirstPage(limit: Int = 10): List<ArticleCardDto> {
        return getArticles(cursor = null, limit = limit).articles
    }
}
