package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.PagedPostsResponse
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.dataOrThrow

/**
 * Posts repository.
 *
 * Wraps the posts + post-comments + post-likes endpoints. The Origin header
 * is passed on every state-changing call to satisfy the backend's CSRF check.
 */
class PostsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of posts (optionally filtered by author). */
    suspend fun getPosts(
        cursor: String? = null,
        limit: Int = 20,
        authorId: String? = null,
    ): PagedPostsResponse {
        return api.getPosts(
            limit = limit,
            cursor = cursor,
            authorId = authorId,
        ).dataOrThrow()
    }

    /** Fetch a single post by ID. */
    suspend fun getPost(id: String): PostDto {
        return api.getPost(id).dataOrThrow()
    }

    /** Create a new text post. */
    suspend fun createPost(content: String): PostDto {
        return api.createPost(
            body = mapOf("content" to content),
            origin = origin,
        ).dataOrThrow()
    }

    /** Delete a post owned by the current user. */
    suspend fun deletePost(id: String): Boolean {
        api.deletePost(id = id, origin = origin)
        return true
    }

    /** Toggle like on a post. Returns (liked, likeCount). */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return api.togglePostLike(id = id, origin = origin).dataOrThrow()
    }

    /** Fetch paginated comments for a post (sorted by newest by default). */
    suspend fun getComments(
        postId: String,
        cursor: String? = null,
        limit: Int = 50,
        sort: String = "newest",
    ): CommentsResponse {
        return api.getPostComments(
            id = postId,
            limit = limit,
            cursor = cursor,
            sort = sort,
        ).dataOrThrow()
    }

    /** Create a top-level comment or a reply (when parentCommentId is set). */
    suspend fun createComment(
        postId: String,
        content: String,
        parentCommentId: String? = null,
    ): CommentDto {
        val body = buildMap {
            put("content", content)
            if (parentCommentId != null) put("parentCommentId", parentCommentId)
        }
        return api.createPostComment(
            id = postId,
            body = body,
            origin = origin,
        ).dataOrThrow()
    }

    /** Toggle like on a comment. */
    suspend fun toggleCommentLike(commentId: String): ToggleLikeResponse {
        return api.toggleCommentLike(id = commentId, origin = origin).dataOrThrow()
    }
}
