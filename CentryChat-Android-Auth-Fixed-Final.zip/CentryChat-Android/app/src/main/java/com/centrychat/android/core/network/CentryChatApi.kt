package com.centrychat.android.core.network

import com.centrychat.android.data.model.ApiResponse
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.AuthMeResponse
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.FeedResponse
import com.centrychat.android.data.model.ForgotPasswordRequest
import com.centrychat.android.data.model.GenericMessageResponse
import com.centrychat.android.data.model.LoginRequest
import com.centrychat.android.data.model.LoginResponse
import com.centrychat.android.data.model.NotificationListResponse
import com.centrychat.android.data.model.PagedPostsResponse
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.ProfileResponse
import com.centrychat.android.data.model.RegisterRequest
import com.centrychat.android.data.model.ResetPasswordRequest
import com.centrychat.android.data.model.SearchAllResponse
import com.centrychat.android.data.model.SuggestedUsersResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.model.UsersListResponse
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit API surface for the CentryChat backend.
 *
 * All endpoints live under `/api/v1/` on the deployed Next.js app.
 * Each endpoint returns [ApiResponse] — the backend's standard envelope
 * is `{ ok: true, data: ... }` for success and
 * `{ ok: false, error: { message, code?, detail? } }` for errors.
 *
 * CSRF: state-changing endpoints (POST/PUT/PATCH/DELETE) require an `Origin`
 * header matching the deployment URL. The [AuthInterceptor] adds this header
 * automatically for every state-changing request.
 *
 * Auth: every authenticated request automatically carries the session cookie
 * via the [PersistentCookieJar] installed on the OkHttp client.
 */
interface CentryChatApi {

    // ── Health & system ─────────────────────────────────────────────────
    @GET("api/v1/health")
    suspend fun getHealth(): ApiResponse<GenericMessageResponse>

    // ── Authentication ─────────────────────────────────────────────────

    @POST("api/v1/auth/login")
    suspend fun login(
        @Body body: LoginRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<LoginResponse>

    @POST("api/v1/auth/register")
    suspend fun register(
        @Body body: RegisterRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<LoginResponse>

    @POST("api/v1/auth/logout")
    suspend fun logout(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/auth/me")
    suspend fun getMe(): ApiResponse<AuthMeResponse>

    @POST("api/v1/auth/forgot-password")
    suspend fun forgotPassword(
        @Body body: ForgotPasswordRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/auth/reset-password")
    suspend fun resetPassword(
        @Body body: ResetPasswordRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/auth/resend-verification")
    suspend fun resendVerification(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Profile (current user) ─────────────────────────────────────────

    @GET("api/v1/profile")
    suspend fun getMyProfile(): ApiResponse<ProfileResponse>

    @PATCH("api/v1/profile")
    suspend fun updateMyProfile(
        @Body body: Map<String, @JvmSuppressWildcards Any?>,
        @Header("Origin") origin: String,
    ): ApiResponse<ProfileResponse>

    // ── Public profiles ────────────────────────────────────────────────

    @GET("api/v1/users/{username}/profile")
    suspend fun getUserProfile(@Path("username") username: String): ApiResponse<UserProfileSummary>

    @GET("api/v1/users/{username}/followers")
    suspend fun getFollowers(
        @Path("username") username: String,
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<UsersListResponse>

    @GET("api/v1/users/{username}/following")
    suspend fun getFollowing(
        @Path("username") username: String,
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<UsersListResponse>

    @POST("api/v1/users/{username}/follow")
    suspend fun followUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/users/{username}/follow")
    suspend fun unfollowUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/users/suggested")
    suspend fun getSuggestedUsers(): ApiResponse<SuggestedUsersResponse>

    @GET("api/v1/users/search")
    suspend fun searchUsers(@Query("q") query: String): ApiResponse<UsersListResponse>

    // ── Feed ───────────────────────────────────────────────────────────

    @GET("api/v1/feed/unified")
    suspend fun getUnifiedFeed(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
        @Query("mix") mix: String? = null,
    ): ApiResponse<FeedResponse>

    @GET("api/v1/feed/trending")
    suspend fun getTrendingFeed(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<FeedResponse>

    // ── Posts ──────────────────────────────────────────────────────────

    @GET("api/v1/posts")
    suspend fun getPosts(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
        @Query("authorId") authorId: String? = null,
    ): ApiResponse<PagedPostsResponse>

    @POST("api/v1/posts")
    suspend fun createPost(
        @Body body: Map<String, @JvmSuppressWildcards String>,
        @Header("Origin") origin: String,
    ): ApiResponse<PostDto>

    @GET("api/v1/posts/{id}")
    suspend fun getPost(@Path("id") id: String): ApiResponse<PostDto>

    @DELETE("api/v1/posts/{id}")
    suspend fun deletePost(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/posts/{id}/like")
    suspend fun togglePostLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    @GET("api/v1/posts/{id}/comments")
    suspend fun getPostComments(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
        @Query("cursor") cursor: String? = null,
        @Query("sort") sort: String = "newest",
    ): ApiResponse<CommentsResponse>

    @POST("api/v1/posts/{id}/comments")
    suspend fun createPostComment(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<CommentDto>

    @POST("api/v1/post-comments/{id}/like")
    suspend fun toggleCommentLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    // ── Articles ───────────────────────────────────────────────────────

    @GET("api/v1/articles")
    suspend fun getArticles(
        @Query("limit") limit: Int = 10,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<ArticleListResponse>

    @GET("api/v1/articles/{id}")
    suspend fun getArticle(@Path("id") id: String): ApiResponse<ArticleDetailDto>

    @POST("api/v1/articles/{id}/like")
    suspend fun toggleArticleLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    @GET("api/v1/articles/{id}/comments")
    suspend fun getArticleComments(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
    ): ApiResponse<CommentsResponse>

    @POST("api/v1/articles/{id}/comments")
    suspend fun createArticleComment(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<CommentDto>

    // ── Notifications ─────────────────────────────────────────────────

    @GET("api/v1/notifications")
    suspend fun getNotifications(
        @Query("limit") limit: Int = 20,
        @Query("beforeId") beforeId: String? = null,
        @Query("unread") unread: String? = null,
    ): ApiResponse<NotificationListResponse>

    @POST("api/v1/notifications/{id}/read")
    suspend fun markNotificationRead(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/notifications/read-all")
    suspend fun markAllNotificationsRead(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Search ────────────────────────────────────────────────────────

    @GET("api/v1/search/all")
    suspend fun searchAll(
        @Query("q") query: String,
        @Query("limit") limit: Int = 20,
        @Query("type") type: String? = null,
    ): ApiResponse<SearchAllResponse>
}
