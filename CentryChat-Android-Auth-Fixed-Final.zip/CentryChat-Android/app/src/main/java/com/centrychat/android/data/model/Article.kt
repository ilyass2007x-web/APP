package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Article DTOs.
 *
 * Mirror the shapes returned by `src/app/api/v1/articles/route.ts`
 * (list endpoint) and `src/app/api/v1/articles/[id]/route.ts` (detail).
 */

@Serializable
data class ArticleCardDto(
    val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
)

@Serializable
data class ArticleDetailDto(
    val id: String,
    val title: String,
    val content: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("showCoverInArticle") val showCoverInArticle: Boolean = true,
    @SerialName("adsEnabled") val adsEnabled: Boolean = true,
    val status: String = "PUBLISHED",
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String = "",
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
    @SerialName("topicIds") val topicIds: List<String> = emptyList(),
)

@Serializable
data class ArticleListResponse(
    val articles: List<ArticleCardDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)
