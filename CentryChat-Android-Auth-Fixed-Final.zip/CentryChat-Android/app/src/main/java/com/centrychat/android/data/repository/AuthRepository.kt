package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.core.network.PersistentCookieJar
import com.centrychat.android.core.storage.SecureSessionStore
import com.centrychat.android.data.model.ApiException
import com.centrychat.android.data.model.ApiResponse
import com.centrychat.android.data.model.AuthMeResponse
import com.centrychat.android.data.model.ForgotPasswordRequest
import com.centrychat.android.data.model.LoginRequest
import com.centrychat.android.data.model.LoginResponse
import com.centrychat.android.data.model.RegisterRequest
import com.centrychat.android.data.model.ResetPasswordRequest
import com.centrychat.android.data.model.UserDto
import com.centrychat.android.data.model.dataOrThrow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Authentication + session repository.
 *
 * This is the ONLY repository that talks to the [SecureSessionStore] + the
 * [PersistentCookieJar]. The rest of the app authenticates implicitly via
 * the OkHttp cookie jar — when the user is logged in, the cookie is sent
 * automatically; when they're not, requests fail with HTTP 401.
 *
 * The repository exposes a [currentUser] StateFlow that the rest of the
 * app observes for the auth state. It's set on login/register + cleared on
 * logout/expired.
 */
class AuthRepository(
    private val api: CentryChatApi,
    private val sessionStore: SecureSessionStore,
    private val appScope: CoroutineScope,
) {
    private val _currentUser = MutableStateFlow<UserDto?>(null)
    val currentUser: StateFlow<UserDto?> = _currentUser.asStateFlow()

    /** The Origin header value — set on every state-changing request to
     *  satisfy the backend's CSRF check. */
    private val origin: String = BuildConfig.API_ORIGIN

    /** Login with email + password. Returns the logged-in user, or throws
     *  an exception with the server's error message.
     *
     *  ERROR HANDLING:
     *   - HTTP 200 + `{ok:true, data:{...}}` → success, returns the user.
     *   - HTTP 401 + `{ok:false, error:{message:"Invalid email or password"}}` → throws ApiException with that message.
     *   - HTTP 403 + `{ok:false, error:{message:"Request blocked by security policy."}}` (CSRF check failure) → throws ApiException.
     *   - HTTP 429 + `{ok:false, error:{message:"Too many requests..."}}` (rate-limited) → throws ApiException.
     *   - HTTP 404 (Netlify "Not Found" — would mean Base URL is wrong) → throws IOException with a clear hint.
     *   - Network failure (no internet, DNS failure, SSL handshake failure) → throws IOException with the original cause.
     *
     *  The previous version called `response.dataOrThrow()` directly, which let
     *  Retrofit throw `HttpException` for non-2xx responses — losing the server's
     *  error message + showing a generic "HTTP 401 ..." string to the user.
     */
    suspend fun login(email: String, password: String): UserDto {
        val response = try {
            api.login(
                body = LoginRequest(email = email.trim(), password = password),
                origin = origin,
            )
        } catch (e: retrofit2.HttpException) {
            // The server returned non-2xx. Extract the structured error
            // message from the response body if present, else fall back
            // to a hint based on the HTTP code.
            throw e.toApiException()
        } catch (e: java.io.IOException) {
            // Network-layer failure (no DNS, no route, SSL handshake, etc.).
            throw java.io.IOException(
                "Could not connect to the server. Check your internet connection and try again.",
                e,
            )
        }
        val data = response.dataOrThrow()
        _currentUser.value = data.user
        return data.user
    }

    /** Register a new account. Returns the newly created user (the backend
     *  auto-logs the user in + sets the session cookie).
     *
     *  Same error-handling logic as [login] — see the comment there for the
     *  full matrix of HTTP codes + how they map to user-facing messages.
     */
    suspend fun register(
        fullName: String,
        email: String,
        username: String,
        password: String,
        gender: String,
        dateOfBirth: String?,
        countryCode: String,
    ): UserDto {
        val response = try {
            api.register(
                body = RegisterRequest(
                    fullName = fullName.trim(),
                    email = email.trim(),
                    username = username.trim(),
                    password = password,
                    confirmPassword = password,
                    gender = gender,
                    dateOfBirth = dateOfBirth,
                    countryCode = countryCode,
                ),
                origin = origin,
            )
        } catch (e: retrofit2.HttpException) {
            throw e.toApiException()
        } catch (e: java.io.IOException) {
            throw java.io.IOException(
                "Could not connect to the server. Check your internet connection and try again.",
                e,
            )
        }
        val data = response.dataOrThrow()
        _currentUser.value = data.user
        return data.user
    }

    /** Send a password-reset email. Returns true on success (or when the
     *  email doesn't exist — the backend always returns success to prevent
     *  email enumeration). */
    suspend fun forgotPassword(email: String): Boolean {
        val response = api.forgotPassword(
            body = ForgotPasswordRequest(email = email.trim()),
            origin = origin,
        )
        return when (response) {
            is ApiResponse.Success -> true
            is ApiResponse.Error -> throw java.io.IOException(response.error.message)
        }
    }

    /** Reset the password using a token from the email link. */
    suspend fun resetPassword(token: String, newPassword: String): Boolean {
        val response = api.resetPassword(
            body = ResetPasswordRequest(
                token = token,
                password = newPassword,
                confirmPassword = newPassword,
            ),
            origin = origin,
        )
        return when (response) {
            is ApiResponse.Success -> true
            is ApiResponse.Error -> throw java.io.IOException(response.error.message)
        }
    }

    /** Resend the email-verification link (for users who skipped verification
     *  at signup). Best-effort — the backend may rate-limit. */
    suspend fun resendVerification(): Boolean {
        val response = api.resendVerification(origin = origin)
        return response is ApiResponse.Success
    }

    /** Fetch the current user from `/api/v1/auth/me`. Returns null if the
     *  session has expired (HTTP 401). */
    suspend fun fetchCurrentUser(): UserDto? {
        return try {
            val response = api.getMe()
            when (response) {
                is ApiResponse.Success -> {
                    val user = response.data.user
                    _currentUser.value = user
                    user
                }
                is ApiResponse.Error -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Log out — calls the backend (best-effort) then clears the local
     *  session store. */
    suspend fun logout() {
        try {
            api.logout(origin = origin)
        } catch (_: Exception) {
            // Network errors during logout are non-fatal — we still clear
            // the local session so the user is signed out on this device.
        }
        clearLocalSession()
    }

    /** Clears the local session without calling the backend. Called by the
     *  [com.centrychat.android.core.network.UnauthorizedInterceptor] when
     *  the backend returns HTTP 401. */
    fun clearLocalSession() {
        appScope.launch {
            sessionStore.clearSession()
        }
        _currentUser.value = null
    }

    /** True if a session cookie is currently stored locally. Note that the
     *  cookie may still be expired on the server side — use [fetchCurrentUser]
     *  to verify against the backend. */
    suspend fun hasLocalSession(): Boolean {
        return sessionStore.hasSession()
    }
}

/**
 * Convert a Retrofit [retrofit2.HttpException] into a user-facing [ApiException]
 * by extracting the structured error message from the response body.
 *
 * The backend returns errors in this shape for all non-2xx responses:
 *   `{ "ok": false, "error": { "message": "...", "code": "...", "detail": "..." } }`
 *
 * When the body parses cleanly, the user sees the server's message verbatim
 * (e.g. "Invalid email or password", "This username is already taken.").
 * When the body is not JSON (e.g. a Netlify 404 "Not Found" page — the
 * classic symptom of a wrong Base URL), the function falls back to a
 * human-readable hint based on the HTTP code.
 *
 * Special cases:
 *   - HTTP 404: almost always means the Base URL is wrong (the deployment
 *     doesn't exist at that URL). The hint says so explicitly so the user
 *     doesn't waste time retrying login with different credentials.
 *   - HTTP 403: usually a CSRF check failure (the Origin header doesn't
 *     match the deployment URL). The hint points to the Origin config.
 *   - HTTP 429: rate-limited. The hint tells the user to wait.
 *   - HTTP 5xx: server-side error. The hint says to try again later.
 */
private fun retrofit2.HttpException.toApiException(): ApiException {
    val code = this.code()
    // Try to parse the structured error body.
    val rawBody = try {
        this.response()?.errorBody()?.string()
    } catch (_: Exception) {
        null
    }
    val serverMessage = rawBody?.let { parseErrorMessage(it) }
    val message = serverMessage ?: when (code) {
        404 -> "The server could not be reached at the configured URL. " +
            "If you are the developer, check API_BASE_URL in app/build.gradle.kts — " +
            "the deployment URL may have changed."
        403 -> "Request blocked by the server's security policy. " +
            "If you are the developer, check that API_ORIGIN in app/build.gradle.kts " +
            "matches the deployment URL exactly (the backend's CSRF check compares them)."
        429 -> "Too many requests. Please wait a moment and try again."
        in 500..599 -> "The server had an error. Please try again later."
        else -> "Request failed (HTTP $code)."
    }
    return ApiException(message, code.toString())
}

/**
 * Parse the structured `{ "ok": false, "error": { "message": "..." } }` body
 * and return the inner message. Returns null if the body is not valid JSON
 * or doesn't match the expected shape (e.g. a plain-text Netlify 404 page).
 */
private fun parseErrorMessage(rawBody: String): String? {
    return try {
        val json = org.json.JSONObject(rawBody)
        // The backend always wraps errors under `error.message`.
        val errorObj = json.optJSONObject("error") ?: return null
        errorObj.optString("message").takeIf { it.isNotBlank() }
    } catch (_: Exception) {
        null
    }
}
