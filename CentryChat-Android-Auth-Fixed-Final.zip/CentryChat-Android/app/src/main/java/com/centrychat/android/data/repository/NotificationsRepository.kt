package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.NotificationDto
import com.centrychat.android.data.model.NotificationListResponse
import com.centrychat.android.data.model.dataOrThrow

/**
 * Notifications repository.
 *
 * Wraps the notifications list + mark-as-read endpoints. The CentryChat
 * backend excludes MESSAGE-type notifications from this list (those are
 * tracked separately via the conversation unread-count badge) — so the
 * activity feed is purely social notifications (likes, follows, comments).
 */
class NotificationsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch the first page of notifications. */
    suspend fun getNotifications(limit: Int = 20, unreadOnly: Boolean = false): NotificationListResponse {
        return api.getNotifications(
            limit = limit,
            beforeId = null,
            unread = if (unreadOnly) "true" else null,
        ).dataOrThrow()
    }

    /** Fetch the next page of notifications (cursor = `beforeId`). */
    suspend fun getNotificationsNext(beforeId: String, limit: Int = 20): NotificationListResponse {
        return api.getNotifications(
            limit = limit,
            beforeId = beforeId,
            unread = null,
        ).dataOrThrow()
    }

    /** Mark a single notification as read. */
    suspend fun markRead(id: String): Boolean {
        api.markNotificationRead(id = id, origin = origin)
        return true
    }

    /** Mark ALL notifications as read. */
    suspend fun markAllRead(): Boolean {
        api.markAllNotificationsRead(origin = origin)
        return true
    }

    /** Convenience: fetch the first page as a flat list. */
    suspend fun getFirstPage(limit: Int = 20): List<NotificationDto> {
        return getNotifications(limit = limit).notifications
    }
}
