package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ProfileResponse
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.model.UsersListResponse
import com.centrychat.android.data.model.dataOrThrow

/**
 * Profile repository.
 *
 * Wraps:
 *  - The current user's profile (`/api/v1/profile` GET + PATCH)
 *  - Public profiles by username (`/api/v1/users/{username}/profile`)
 *  - Follow / unfollow (`/api/v1/users/{username}/follow`)
 *  - Followers + following lists
 */
class ProfileRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch the current user's full profile (includes private fields). */
    suspend fun getMyProfile(): ProfileResponse {
        return api.getMyProfile().dataOrThrow()
    }

    /** Update the current user's profile. Pass only the fields to change. */
    suspend fun updateMyProfile(changes: Map<String, Any?>): ProfileResponse {
        return api.updateMyProfile(body = changes, origin = origin).dataOrThrow()
    }

    /** Fetch a public profile by username. */
    suspend fun getPublicProfile(username: String): UserProfileSummary {
        return api.getUserProfile(username = username).dataOrThrow()
    }

    /** Follow a user. */
    suspend fun follow(username: String): Boolean {
        api.followUser(username = username, origin = origin)
        return true
    }

    /** Unfollow a user. */
    suspend fun unfollow(username: String): Boolean {
        api.unfollowUser(username = username, origin = origin)
        return true
    }

    /** Fetch a user's followers (paginated). */
    suspend fun getFollowers(
        username: String,
        cursor: String? = null,
        limit: Int = 20,
    ): UsersListResponse {
        return api.getFollowers(
            username = username,
            limit = limit,
            cursor = cursor,
        ).dataOrThrow()
    }

    /** Fetch the users a user is following (paginated). */
    suspend fun getFollowing(
        username: String,
        cursor: String? = null,
        limit: Int = 20,
    ): UsersListResponse {
        return api.getFollowing(
            username = username,
            limit = limit,
            cursor = cursor,
        ).dataOrThrow()
    }

    /** Fetch a list of suggested users (for the "Who to follow" widget). */
    suspend fun getSuggestedUsers(): List<UserProfileSummary> {
        return api.getSuggestedUsers().dataOrThrow().users
    }
}
