package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The backend's standard response envelope.
 *
 * Success: `{ "ok": true, "data": <payload> }`
 * Error:   `{ "ok": false, "error": { "message": "...", "code": "...", "detail": "..." } }`
 *
 * The Retrofit kotlinx-serialization converter deserializes this into [ApiResponse.Success]
 * or [ApiResponse.Error] depending on the value of `ok`. Callers can `when` over
 * the result without manually parsing the JSON.
 *
 * The backend ALWAYS returns 200 OK for application-level errors (it's a Next.js
 * convention — HTTP status codes are used only for transport-level failures).
 * However, some endpoints (like forgot-password) DO return non-200 codes for
 * specific failures (502 when Resend fails). We capture both the body AND the
 * HTTP code via Retrofit's `Response<ApiResponse<T>>` wrapper where needed.
 */
@Serializable
sealed class ApiResponse<out T> {

    @Serializable
    data class Success<out T>(
        val ok: Boolean = true,
        val data: T,
    ) : ApiResponse<T>()

    @Serializable
    data class Error(
        val ok: Boolean = false,
        val error: ApiError,
    ) : ApiResponse<Nothing>()

    @Serializable
    data class ApiError(
        val message: String,
        val code: String? = null,
        val detail: String? = null,
        val suggestions: List<String>? = null,
    )
}

/**
 * A wrapper used by Retrofit for endpoints where we need to distinguish between
 * transport-level success/failure (HTTP status code) and application-level
 * success/failure (the `ok` field in the body).
 *
 * Most callers will use the [ApiResponse] extension functions instead.
 */
typealias HttpApiResponse<T> = retrofit2.Response<ApiResponse<T>>

/**
 * Returns the success data, or null if this is an error response.
 */
fun <T> ApiResponse<T>.dataOrNull(): T? = (this as? ApiResponse.Success)?.data

/**
 * Returns the error message, or null if this is a success response.
 */
fun <T> ApiResponse<T>.errorMessage(): String? = (this as? ApiResponse.Error)?.error?.message

/**
 * Returns the success data, or throws an [ApiException] with the error message.
 */
fun <T> ApiResponse<T>.dataOrThrow(): T {
    return when (this) {
        is ApiResponse.Success -> data
        is ApiResponse.Error -> throw ApiException(error.message, error.code)
    }
}

/**
 * Exception thrown by [dataOrThrow] when the backend returns an error.
 */
class ApiException(
    message: String,
    val code: String? = null,
) : Exception(message)
