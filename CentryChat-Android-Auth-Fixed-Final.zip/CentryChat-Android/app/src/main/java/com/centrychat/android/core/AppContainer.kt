package com.centrychat.android.core

import android.content.Context
import com.centrychat.android.core.network.AuthInterceptor
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.core.network.PersistentCookieJar
import com.centrychat.android.core.network.RetrofitFactory
import com.centrychat.android.core.network.UnauthorizedInterceptor
import com.centrychat.android.core.storage.SecureSessionStore
import com.centrychat.android.data.repository.ArticlesRepository
import com.centrychat.android.data.repository.AuthRepository
import com.centrychat.android.data.repository.FeedRepository
import com.centrychat.android.data.repository.NotificationsRepository
import com.centrychat.android.data.repository.PostsRepository
import com.centrychat.android.data.repository.ProfileRepository
import com.centrychat.android.data.repository.SearchRepository
import com.centrychat.android.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import com.centrychat.android.BuildConfig

/**
 * The app's dependency container.
 *
 * Constructed once per process (see [com.centrychat.android.CentryChatApp]).
 * Holds singletons that the ViewModels depend on:
 *   - The OkHttp client (with a persistent cookie jar + auth interceptor)
 *   - The Retrofit instance bound to the CentryChat backend
 *   - The API surface ([CentryChatApi])
 *   - The repositories (auth, feed, posts, articles, notifications, etc.)
 *
 * Manual DI was chosen over Hilt/Koin to keep the build surface small —
 * the project has fewer than 10 repositories and a single API, so a 200-line
 * DI framework would be overkill. ViewModels obtain dependencies through
 * a [androidx.lifecycle.ViewModelProvider.Factory] (see AppViewModels.kt).
 *
 * CRASH-SAFETY (Root Cause #2 fix):
 *  - The previous version eagerly constructed `cookieJar` (which called
 *    `loadFromDisk()` synchronously, forcing EncryptedSharedPreferences
 *    init on the main thread during Application.onCreate()). On some
 *    devices this threw + killed the process.
 *  - Now the cookie jar is lazy (its `cache` is loaded on first use, not
 *    at construction). This means the constructor is non-throwing —
 *    Application.onCreate() cannot crash on this code path anymore.
 *
 * @param appContext The application context — used to open encrypted
 * SharedPreferences for the cookie/session store.
 */
class AppContainer(
    appContext: Context,
) {
    /** The application's CoroutineScope — used for one-off fire-and-forget
     *  work (e.g. flushing analytics events, polling notifications). */
    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // ── Storage ──────────────────────────────────────────────────────────
    private val secureSessionStore: SecureSessionStore = SecureSessionStore(appContext)

    // ── Networking ────────────────────────────────────────────────────────
    /** Persists session cookies to encrypted SharedPreferences so the user
     *  stays logged in across app launches (until the 7-day TTL expires). */
    private val cookieJar: PersistentCookieJar = PersistentCookieJar(appContext)

    /** Detects HTTP 401 responses and triggers a logout flow (clears the
     *  session store + signals the UI to navigate back to the login screen). */
    val unauthorizedInterceptor = UnauthorizedInterceptor(secureSessionStore, appScope)

    /** Adds the session cookie to every request + sets the `Origin` header
     *  to the configured production URL so the backend's CSRF check passes. */
    private val authInterceptor = AuthInterceptor(cookieJar)

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        // WARN level: logs request/response lines + headers, but NEVER bodies.
        // Bodies may contain user passwords, post content, or session cookies —
        // all of which are forbidden in production logs.
        level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.HEADERS
        } else {
            HttpLoggingInterceptor.Level.NONE
        }
        redactHeader("Cookie")
        redactHeader("Set-Cookie")
        redactHeader("Authorization")
    }

    /** The shared OkHttp client. */
    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .addNetworkInterceptor(unauthorizedInterceptor)
        .retryOnConnectionFailure(true)
        .build()

    /** The Retrofit-backed API. */
    val api: CentryChatApi = RetrofitFactory.create(okHttpClient).create(CentryChatApi::class.java)

    // ── Repositories ─────────────────────────────────────────────────────
    val authRepository: AuthRepository = AuthRepository(api, secureSessionStore, appScope)
    val feedRepository: FeedRepository = FeedRepository(api)
    val postsRepository: PostsRepository = PostsRepository(api)
    val articlesRepository: ArticlesRepository = ArticlesRepository(api)
    val notificationsRepository: NotificationsRepository = NotificationsRepository(api)
    val profileRepository: ProfileRepository = ProfileRepository(api)
    val searchRepository: SearchRepository = SearchRepository(api)
    val settingsRepository: SettingsRepository = SettingsRepository(appContext)

    /** True once the user has an active session cookie. */
    suspend fun hasSession(): Boolean = secureSessionStore.hasSession()
}
