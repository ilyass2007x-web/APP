package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The user identity returned by the backend's auth endpoints.
 *
 * Mirrors the `SafeUser` type in `src/lib/auth/index.ts` of the CentryChat
 * web project. All fields are nullable-safe — the backend may omit optional
 * fields. The kotlinx-serialization `ignoreUnknownKeys = true` flag in
 * [com.centrychat.android.core.network.RetrofitFactory] handles extra fields
 * gracefully.
 */
@Serializable
data class UserDto(
    val id: String,
    val fullName: String,
    val email: String,
    val username: String,
    @SerialName("emailVerified") val emailVerified: String? = null,
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
    @SerialName("twoFactorEnabled") val twoFactorEnabled: Boolean = false,
    val bio: String? = null,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    val language: String = "en",
    @SerialName("createdAt") val createdAt: String = "",
)

/**
 * The minimal public profile returned by `GET /api/v1/users/{username}/profile`.
 *
 * Mirrors `UserProfileSummary` in `src/lib/follow.ts`. Note that the public
 * profile intentionally does NOT include `email`, `gender`, or `dateOfBirth` —
 * the backend redacts these for privacy.
 */
@Serializable
data class UserProfileSummary(
    val id: String,
    val fullName: String,
    val username: String,
    val avatarColor: String? = null,
    val avatarUrl: String? = null,
    val isVerified: Boolean = false,
    val bio: String? = null,
    @SerialName("followersCount") val followersCount: Long = 0,
    @SerialName("followingCount") val followingCount: Long = 0,
    @SerialName("postsCount") val postsCount: Long = 0,
    val isFollowing: Boolean = false,
    val isFollowedBy: Boolean = false,
)

/**
 * The richer profile returned by `GET /api/v1/profile` (the current user's
 * own profile). Includes `email`, `language`, `notificationPrefs`, etc.
 * that are NEVER returned for other users.
 */
@Serializable
data class ProfileResponse(
    val user: ProfileDetailDto? = null,
)

@Serializable
data class ProfileDetailDto(
    val id: String,
    val fullName: String,
    val email: String,
    val username: String,
    val bio: String? = null,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val isVerified: Boolean = false,
    val role: String = "USER",
    val status: String = "ACTIVE",
    val language: String = "en",
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    @SerialName("notificationPrefs") val notificationPrefs: NotificationPrefs? = null,
)

@Serializable
data class NotificationPrefs(
    val message: Boolean = true,
    val security: Boolean = true,
    val system: Boolean = true,
    val account: Boolean = true,
    val moderation: Boolean = true,
)
