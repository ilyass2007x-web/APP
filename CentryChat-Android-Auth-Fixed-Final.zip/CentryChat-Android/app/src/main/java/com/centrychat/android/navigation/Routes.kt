package com.centrychat.android.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search

/**
 * The navigation routes for the app.
 */
object Routes {

    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    const val RESET_PASSWORD = "reset_password?token={token}"
    const val RESET_PASSWORD_BASE = "reset_password"

    const val HOME = "home"
    const val SEARCH = "search"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"

    const val POST_DETAIL = "post/{postId}"
    const val POST_DETAIL_BASE = "post"
    const val ARTICLE_DETAIL = "article/{articleId}"
    const val ARTICLE_DETAIL_BASE = "article"
    const val USER_PROFILE = "user/{username}"
    const val USER_PROFILE_BASE = "user"
    const val FOLLOWERS = "followers/{username}"
    const val FOLLOWERS_BASE = "followers"
    const val FOLLOWING = "following/{username}"
    const val FOLLOWING_BASE = "following"
    const val EDIT_PROFILE = "edit_profile"
    const val COMMENTS = "comments/{postId}"
    const val COMMENTS_BASE = "comments"

    fun postDetail(postId: String) = "$POST_DETAIL_BASE/$postId"
    fun articleDetail(articleId: String) = "$ARTICLE_DETAIL_BASE/$articleId"
    fun userProfile(username: String) = "$USER_PROFILE_BASE/$username"
    fun followers(username: String) = "$FOLLOWERS_BASE/$username"
    fun following(username: String) = "$FOLLOWING_BASE/$username"
    fun resetPassword(token: String) = "$RESET_PASSWORD_BASE?token=$token"
    fun comments(postId: String) = "$COMMENTS_BASE/$postId"
}

/**
 * The bottom-nav destinations.
 */
enum class BottomNavDestination(
    val route: String,
    val labelRes: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
) {
    HOME(
        route = Routes.HOME,
        labelRes = com.centrychat.android.R.string.nav_home,
        icon = Icons.AutoMirrored.Filled.List,
        selectedIcon = Icons.AutoMirrored.Filled.List,
    ),
    SEARCH(
        route = Routes.SEARCH,
        labelRes = com.centrychat.android.R.string.nav_search,
        icon = Icons.Filled.Search,
        selectedIcon = Icons.Filled.Search,
    ),
    NOTIFICATIONS(
        route = Routes.NOTIFICATIONS,
        labelRes = com.centrychat.android.R.string.nav_notifications,
        icon = Icons.Filled.Notifications,
        selectedIcon = Icons.Filled.Notifications,
    ),
    PROFILE(
        route = Routes.PROFILE,
        labelRes = com.centrychat.android.R.string.nav_profile,
        icon = Icons.Filled.Person,
        selectedIcon = Icons.Filled.Person,
    ),
}
