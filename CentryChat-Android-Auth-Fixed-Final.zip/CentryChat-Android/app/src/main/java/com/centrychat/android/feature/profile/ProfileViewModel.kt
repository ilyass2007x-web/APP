package com.centrychat.android.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ProfileDetailDto
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.repository.ProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository

    private val _profileState = MutableStateFlow<UiState<UserProfileSummary>>(UiState.Loading)
    val profileState: StateFlow<UiState<UserProfileSummary>> = _profileState.asStateFlow()

    private val _isFollowing = MutableStateFlow(false)
    val isFollowing: StateFlow<Boolean> = _isFollowing.asStateFlow()

    fun loadProfile(username: String?) {
        _profileState.value = UiState.Loading
        viewModelScope.launch {
            try {
                if (username.isNullOrBlank()) {
                    // Load the current user's own profile.
                    val me = repo.getMyProfile().user
                    if (me == null) {
                        _profileState.value = UiState.Empty
                        return@launch
                    }
                    val profile = UserProfileSummary(
                        id = me.id,
                        fullName = me.fullName,
                        username = me.username,
                        avatarColor = me.avatarColor,
                        avatarUrl = me.avatarUrl,
                        isVerified = me.isVerified,
                        bio = me.bio,
                        followersCount = 0,
                        followingCount = 0,
                        postsCount = 0,
                        isFollowing = false,
                        isFollowedBy = false,
                    )
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = false
                } else {
                    val profile = repo.getPublicProfile(username)
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = profile.isFollowing
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _profileState.value = UiState.Error(e.message ?: "Could not load profile.")
            }
        }
    }

    fun toggleFollow(username: String) {
        viewModelScope.launch {
            try {
                if (_isFollowing.value) {
                    repo.unfollow(username)
                    _isFollowing.value = false
                } else {
                    repo.follow(username)
                    _isFollowing.value = true
                }
            } catch (_: Exception) {
                // best-effort
            }
        }
    }
}

class EditProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository

    private val _profile = MutableStateFlow<ProfileDetailDto?>(null)
    val profile: StateFlow<ProfileDetailDto?> = _profile.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveError = MutableStateFlow<String?>(null)
    val saveError: StateFlow<String?> = _saveError.asStateFlow()

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    fun load() {
        viewModelScope.launch {
            try {
                val me = repo.getMyProfile().user
                _profile.value = me
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun save(
        fullName: String,
        username: String,
        bio: String?,
        avatarUrl: String?,
        language: String,
        gender: String?,
        dateOfBirth: String?,
        countryCode: String?,
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            _saveError.value = null
            try {
                val changes = buildMap {
                    put("fullName", fullName)
                    put("username", username)
                    put("bio", bio)
                    put("avatarUrl", avatarUrl)
                    put("language", language)
                    if (gender != null) put("gender", gender)
                    if (dateOfBirth != null) put("dateOfBirth", dateOfBirth)
                    if (countryCode != null) put("countryCode", countryCode)
                }
                val updated = repo.updateMyProfile(changes)
                _profile.value = updated.user
                _saved.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _saveError.value = e.message ?: "Could not save profile."
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun consumeSaved() {
        _saved.value = false
    }
}
